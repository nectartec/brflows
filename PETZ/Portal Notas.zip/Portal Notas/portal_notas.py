import streamlit as st
import streamlit_authenticator as stauth
from dependencies import add_registro, consulta, consulta_geral, cria_tabela
from time import sleep
import base64

# Configura a página com título e ícone
st.set_page_config(page_title="Portal Automações Petz", page_icon=":paw_prints:")

# Função para converter imagem em base64
def image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode()
    return encoded_string

# Caminho da imagem do logotipo
logo_path = "petz-logo.png" 
logo_base64 = image_to_base64(logo_path)

# Adiciona o logotipo da Petz e o título
st.markdown(
    f"""
    <style>
        .title {{
            font-size: 30px;
            font-weight: bold;
            color: #005BAA;
            text-align: center;
            margin-top: -50px;
        }}
        .logo {{
            position: absolute;
            top: 10px;
            left: 10px;
            width: 100px;
        }}
    </style>
    <img src="data:image/png;base64,{logo_base64}" class="logo">
    <div class="title">Portal Automações Petz</div>
    """,
    unsafe_allow_html=True
)

def main():
    try:
        consulta_geral()
    except:
        cria_tabela()

    db_query = consulta_geral()

    registros = {'usernames': {}}
    for data in db_query:
        registros['usernames'][data[1]] = {'name': data[0], 'password': data[2]}

    COOKIE_EXPIRY_DAYS = 30
    authenticator = stauth.Authenticate(
        registros,
        'random_cookie_name',
        'random_signature_key',
        COOKIE_EXPIRY_DAYS,
    )
    if 'clicou_registrar' not in st.session_state:
        st.session_state['clicou_registrar'] = False

    if st.session_state['clicou_registrar'] == False:
        login_form(authenticator=authenticator)
    else:
        usuario_form()


def login_form(authenticator):
    name, authentication_status, username = authenticator.login('Login')
    if authentication_status:
        authenticator.logout('Logout', 'main')
        st.write(f'*{name} está logado!*')
        st.title('ÁREA DO DASHBOARD')
    elif authentication_status == False:
        st.error('Usuário ou senha incorretos')
    elif authentication_status == None:
        st.warning('Insira um nome de usuário e uma senha')
        clicou_em_registrar = st.button("Registrar")
        if clicou_em_registrar:
            st.session_state['clicou_registrar'] = True
            st.rerun()


def confirmation_msg():
    hashed_password = stauth.Hasher([st.session_state.pswrd]).generate()
    if st.session_state.pswrd != st.session_state.confirm_pswrd:
        st.warning('Senhas não conferem')
        sleep(3)
    elif consulta(st.session_state.user):
        st.warning('Nome de usuário já existe.')
        sleep(3)
    else:
        add_registro(st.session_state.nome, st.session_state.user, hashed_password[0])
        st.success('Registro efetuado!')
        sleep(3)


def usuario_form():
    with st.form(key="test", clear_on_submit=True):
        nome = st.text_input("Nome", key="nome")
        username = st.text_input("Usuário", key="user")
        password = st.text_input("Password", key="pswrd", type="password")
        confirm_password = st.text_input("Confirm Password", key="confirm_pswrd", type="password")
        submit = st.form_submit_button(
            "Salvar", on_click=confirmation_msg,
        )
    clicou_em_fazer_login = st.button("Fazer Login")
    if clicou_em_fazer_login:
        st.session_state['clicou_registrar'] = False
        st.rerun()


if __name__ == "__main__":
    main()
