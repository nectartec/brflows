#!/bin/bash

zip -r "emailextract.zip" * -x "emailextract.zip"