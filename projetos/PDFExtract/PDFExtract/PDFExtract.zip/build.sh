#!/bin/bash

zip -r "PDFExtract.zip" * -x "PDFExtract.zip"