#!/bin/bash

zip -r "HelloBot.zip" * -x "HelloBot.zip"