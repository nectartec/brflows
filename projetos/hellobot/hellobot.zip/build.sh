#!/bin/bash

zip -r "hellobot.zip" * -x "hellobot.zip"